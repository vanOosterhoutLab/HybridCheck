installed <- installed.packages()
# Packages required from R's package manager:
message("Setting CRAN mirror")
chooseCRANmirror(ind = 83)
pkg <- c("devtools", "shiny", "ggplot2", "png", "grid", "gridExtra", "ape", "Rcpp")
message("Installing needed packages")
new.pkg <- pkg[!(pkg %in% installed)]
if(length(new.pkg)){install.packages(new.pkg)}
if(!("Biostrings" %in% installed)){
  source("http://bioconductor.org/biocLite.R")
  biocLite()
  biocLite("Biostrings")
}
if(!("HybRIDS" %in% installed)){
  library(devtools)
  install_github("Ward9250/HybRIDS")
}
if(!("shinyBS" %in% installed)){
  library(devtools)
  install_github("ebailey78/shinyBS")
}