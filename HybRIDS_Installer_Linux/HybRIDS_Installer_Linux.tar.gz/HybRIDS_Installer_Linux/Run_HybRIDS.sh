Rscript -e "library(shiny); library(shinyBS); runGitHub('HybRIDSapp', 'Ward9250', launch.browser = TRUE)"
