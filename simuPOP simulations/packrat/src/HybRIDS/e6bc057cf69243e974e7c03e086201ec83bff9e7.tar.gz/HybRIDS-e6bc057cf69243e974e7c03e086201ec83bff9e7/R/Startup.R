.onAttach <- function(...){
  cat("\nTACTTTGTACCTAAGTATGCATTACGTTACGTTAGTAGCTGGACCTAGTAAATCGGA     
,--.  ,--.         ,--.   ,------. ,--.,------.   ,---.
|  '--'  |,--. ,--.|  |-. |  .--. '|  ||  .-.  \\ '   .-'
|  .--.  | \\  '  / | .-. '|  '--'.'|  ||  |  \\  :`.  `-.
|  |  |  |  \\   '  | `-' ||  |\\  \\ |  ||  '--'  /.-'    |
`--'  `--'.-'  /    `---' `--' '--'`--'`-------' `-----'
          `---'
ATGAAACATGGATTCATACG - Version 1.0 - CGACCTGGATCATTTAGCCT\n\n
Hybridisation, Recombination and Introgression Detection
                   and Dating Package.\n
-----------------=========****=========------------------
Cite: TBD
Licence: GPL (Like R and most packages).
http://ward9250.github.io/HybRIDS/
-----------------=========****=========------------------\n")
}