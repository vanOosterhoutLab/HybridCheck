library(RCurl)
if(FALSE) {
getURL("http://curl.haxx.se/mail/archive-2004-04/0035.html",
        proxy="wwwproxy.ru.ac.za:3128", proxyauth=TRUE,
        proxyuserpwd="mysuername:mypassword")  #withrelevant username etc
}
