Rscript -e "library(shiny); library(shinydashboard); runGitHub('HybRIDSapp', 'Ward9250', launch.browser = TRUE)"
